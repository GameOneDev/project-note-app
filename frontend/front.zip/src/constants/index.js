// Raspberry PI server
export const API_URL = "http://alt.gameoneyt.com:8000/api/";

// localhost server
// export const API_URL = "http://localhost:8000/api/";