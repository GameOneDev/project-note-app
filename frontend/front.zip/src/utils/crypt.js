// import { Hash } from "crypto";
// import { sha256 } from "node-forge";
// const { createHmac } = await import('file:crypto');


export function crypt (pass){
    // var hashObj = new jsSHA("SHA-512", "TEXT", {numRounds: 1});
    // hashObj.update(pass.value);
    // var hash = hashObj.getHash("HEX");
    // return Hash(pass);


    return hash;
    
    }